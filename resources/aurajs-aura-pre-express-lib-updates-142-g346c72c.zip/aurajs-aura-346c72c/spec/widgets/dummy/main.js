define({
  initialize: function () {
    this.html('dummy !');
  }
});
